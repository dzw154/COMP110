"""Ex00."""

__author__ = "730677774"

print("Hello, world.")