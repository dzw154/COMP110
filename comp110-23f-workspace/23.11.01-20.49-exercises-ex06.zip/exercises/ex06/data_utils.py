"""Dictionary related utility functions."""

__author__ = ""

# Define your functions below