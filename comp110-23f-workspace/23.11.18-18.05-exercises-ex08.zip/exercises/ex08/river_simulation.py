"""Testing the river class."""

from exercises.ex08.river import River

my_river: River = River(10, 2)

my_river.view_river()
my_river.one_river_week()